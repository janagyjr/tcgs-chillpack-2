1. Copy zombie.properties from this folder
2. Go to assets\minecraft\optifine\cem
3. Paste and replace zombie.properties